#include<stdio.h>
int main(){
  printf("%.1lf\n", 8.0/5.0);
  return 0;
}
