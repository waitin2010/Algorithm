#include<stdio.h>
#include<math.h>
int main(){
  printf("%.8lf\n", 1+2*sqrt(3)/(5-0.1));
  return 0;
}
